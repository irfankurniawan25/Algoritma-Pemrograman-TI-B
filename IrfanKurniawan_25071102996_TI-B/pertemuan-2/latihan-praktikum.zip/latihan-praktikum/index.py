from myMath import penambahan, pengurangan, perkalian, pembagian, fibbonacci

tambah = penambahan(10,25)
kurang = pengurangan(80,15)
kali = perkalian(7,8)
bagi = pembagian(100,20)
fibbo = fibbonacci(5)

print(tambah)
print(kurang)
print(kali)
print(bagi)