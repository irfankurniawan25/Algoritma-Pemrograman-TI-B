def penambahan(a,b):
    return a + b

def pengurangan(a, b):
    return a - b

def perkalian(a,b):
    return a * b

def pembagian(a,b):
    return a / b

def modulus(a,b):
    return a % b

def fibbonacci(n):
    total = []
    if n <= 1:
        return n
    else:
        total.append(n - 1)
        total.append(n - 2)
        

print(fibbonacci(5))
        